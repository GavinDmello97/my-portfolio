// eslint-disable-next-line import/no-anonymous-default-export
const reduxApiCallers = {};

export default reduxApiCallers;
